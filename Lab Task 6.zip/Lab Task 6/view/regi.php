<form action="../controller/regv.php" method="post"><pre>

  
User Name:
<input type="text" name="uname"><br/>
Password:
<input type="password" name="pass"><br/>
Confirm Password:
<input type="password" name="confpass"><br/>
E Mail:
<input type="email" name="email"><br/>
<input type="submit" name="sbt" value="submit" />
</pre>
</form>
<a href="login.php">Login</a><br/>
<a href="index.html">Home</a><br/>